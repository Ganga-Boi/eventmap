"""
EventMap — Skabelon til ny kilde
==================================
Kopiér denne fil, omdøb den, og implementér _fetch() og _parse().
Tilføj derefter scraperen til SCRAPERS-listen i pipeline.py.

Eksempel: cp new_source_template.py nakkeosten_scraper.py
"""

from base_scraper import BaseScraper
from schema import Event


class NewSourceScraper(BaseScraper):

    # ── 1. Sæt kildenavn (skal matche 'source' i schema.py) ──────────────────
    source_name = "Nakkeosten"  # <-- skift dette

    # ── 2. Implementér _fetch() ───────────────────────────────────────────────
    async def _fetch(self) -> list:
        """
        Hent rådata fra kilden.

        Vælg tilgang:
          A) iCal:      requests.get(url).text → icalendar.Calendar.from_ical()
          B) HTML:      Playwright page.query_selector_all(".event")
          C) API/JSON:  requests.get(api_url).json()
          D) RSS:       feedparser.parse(rss_url).entries
          E) Manuel:    sheets_adapter.read_manual_inputs(doc)

        Returnér liste af råelementer — ét element per event.
        """
        # Eksempel: simpel HTTP-side
        # import requests
        # from bs4 import BeautifulSoup
        # resp = requests.get("https://example.com/events")
        # soup = BeautifulSoup(resp.text, "html.parser")
        # return soup.select(".event-item")

        raise NotImplementedError("Implementér _fetch()")

    # ── 3. Implementér _parse() ───────────────────────────────────────────────
    def _parse(self, item) -> Event | None:
        """
        Transformer ét rå-element til Event.
        Returnér None for at springe et element over.

        Husk:
          - date skal være ISO 8601: "2025-04-23"
          - source skal matche source_name
          - source_url er det direkte link til event-siden (ikke Facebook-post)
        """
        # Eksempel:
        # title = item.select_one("h2").get_text(strip=True)
        # if not title:
        #     return None
        # return Event(
        #     title=title,
        #     date="2025-04-23",
        #     location="DTU Campus",
        #     source=self.source_name,
        #     source_url="https://...",
        # )

        raise NotImplementedError("Implementér _parse()")


# ── 4. Test standalone ────────────────────────────────────────────────────────
if __name__ == "__main__":
    import asyncio
    scraper = NewSourceScraper()
    events = asyncio.run(scraper.run())
    print(f"Hentet: {len(events)} events")
    for e in events[:3]:
        print(f"  [{e.date}] {e.title} — {e.source_url}")
