"""
EventMap — Base Scraper
========================
Alle scrapers arver BaseScraper.
Det sikrer konsistent interface: hvert kald returnerer list[Event].

Tilføj ny kilde:
    1. Opret ny fil, fx 'nakkeosten_scraper.py'
    2. Arv BaseScraper
    3. Implementér _fetch() og _parse()
    4. Registrér i pipeline.py

Ingen ændringer i schema.py, sheets_adapter.py eller UI.
"""

from abc import ABC, abstractmethod
from schema import Event


class BaseScraper(ABC):
    """Interface som alle scrapers skal overholde."""

    source_name: str = ""  # Sæt i subklasse, fx "IDA"

    async def run(self) -> list[Event]:
        """
        Kør scraperen. Returnerer list[Event] — altid.
        Fejler roligt og returnerer tom liste ved problemer.
        """
        try:
            raw = await self._fetch()
            events = [e for item in raw if (e := self._parse(item)) is not None]
            print(f"[{self.source_name}] {len(events)} events hentet")
            return events
        except Exception as ex:
            print(f"[{self.source_name}] Fejl: {ex}")
            return []

    @abstractmethod
    async def _fetch(self) -> list:
        """
        Hent rådata fra kilden.
        Returner liste af rå-elementer (HTML-elementer, dict, iCal-komponenter osv.)
        """
        ...

    @abstractmethod
    def _parse(self, item) -> Event | None:
        """
        Transformer ét rå-element til Event.
        Returner None hvis elementet skal springes over.
        """
        ...
