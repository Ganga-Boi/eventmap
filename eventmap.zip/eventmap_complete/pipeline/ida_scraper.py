"""
EventMap — IDA Scraper (Cludo REST API)
========================================
Cludo er et REST API. Vi behøver IKKE Playwright.

Flowet:
  1. Hent ida.dk/soeg — find customerId + engineId i page source
  2. POST til api.cludo.com/api/v3/{customerId}/{engineId}/search
  3. Parser JSON-response direkte — ingen HTML-parsing

Det eliminerer den mest skrøbelige del: Playwright + CSS-selektorer.

Krav: pip install requests
"""

import re
import json
import time
import requests
from datetime import datetime

from base_scraper import BaseScraper
from schema import Event

# ── Konfiguration ──────────────────────────────────────────────────────────────

IDA_SEARCH_PAGE = "https://ida.dk/soeg"
CLUDO_API_BASE  = "https://api.cludo.com/api/v3"

# Sæt disse manuelt efter at køre find_cludo_ids() nedenfor
# Eller lad scraperen finde dem automatisk fra page source
CUSTOMER_ID = None  # fx 4545589
ENGINE_ID   = None  # fx 7578030

# Søgeparametre — mappes direkte fra den originale IDA URL
SEARCH_PARAMS = {
    "query": "*",
    "filters": {
        "Category":    ["Arrangementer"],
        "City":        ["København"],
        "Organizer":   ["IDA Studieevents", "DTU studieevents", "København studieevents"],
        "RelevantFor": ["Studerende"],
        "Status":      ["Afholdes", "Venteliste"],
    },
    "sort": [
        {"field": "StartDate_date", "order": "asc"},
        {"field": "DatePublished_date", "order": "asc"},
    ],
    "itemsPerPage": 20,
    "page": 1,
    "responseType": "JsonObject",  # Vi vil have JSON, ikke HTML
}

DANISH_MONTHS = {
    "januar": 1, "februar": 2, "marts": 3, "april": 4,
    "maj": 5, "juni": 6, "juli": 7, "august": 8,
    "september": 9, "oktober": 10, "november": 11, "december": 12,
}

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "EventMap/1.0 (+https://github.com/eventmap)"})


# ── Scraper ────────────────────────────────────────────────────────────────────

class IDAScraper(BaseScraper):
    source_name = "IDA"

    def __init__(self):
        self._customer_id = CUSTOMER_ID
        self._engine_id   = ENGINE_ID

    async def _fetch(self) -> list[dict]:
        """
        Henter events via Cludo REST API.
        Returnerer liste af raw result-dicts fra Cludo JSON-response.
        """
        # Find IDs hvis ikke sat manuelt
        if not self._customer_id or not self._engine_id:
            self._customer_id, self._engine_id = _find_cludo_ids()
            if not self._customer_id:
                print("[IDA] Kunne ikke finde Cludo IDs — kør find_cludo_ids() manuelt")
                return []

        results = []
        page = 1

        while True:
            batch = _cludo_search(self._customer_id, self._engine_id, page)
            if not batch:
                break

            results.extend(batch)
            print(f"[IDA] Side {page}: {len(batch)} events (total: {len(results)})")

            if len(batch) < SEARCH_PARAMS["itemsPerPage"]:
                break  # Sidste side

            page += 1
            time.sleep(0.5)  # Vær pæn mod Cludo API

        return results

    def _parse(self, item: dict) -> Event | None:
        """Parser ét Cludo JSON-resultat til Event."""
        title = (item.get("Title") or item.get("title") or "").strip()
        if not title:
            return None

        # Cludo returnerer typisk disse felter — navnene varierer per kundes konfiguration
        url  = item.get("Url") or item.get("url") or item.get("PageUrl") or ""
        desc = item.get("Description") or item.get("description") or item.get("Summary") or ""
        desc = str(desc).strip()[:300]

        # Dato — Cludo returnerer typisk ISO-format eller dansk tekst
        raw_date  = item.get("StartDate") or item.get("Date") or item.get("EventDate") or ""
        date_str, start_time, end_time = _parse_date(str(raw_date))

        # Backup: prøv EndDate
        if not end_time:
            raw_end = item.get("EndDate") or item.get("EndTime") or ""
            if raw_end:
                _, _, end_time = _parse_date(str(raw_end))

        location  = str(item.get("Location") or item.get("City") or "").strip()
        organizer = str(item.get("Organizer") or item.get("Host") or "IDA").strip()
        price     = str(item.get("Price") or item.get("MemberPrice") or "").strip()
        category  = _guess_category(title, item.get("Category") or "")

        return Event(
            title     = title,
            date      = date_str,
            start_time= start_time,
            end_time  = end_time,
            location  = location,
            organizer = organizer or "IDA Studieevents",
            category  = category,
            price     = price or "Gratis",
            description = desc,
            source    = "IDA",
            source_url= url,
        )


# ── Cludo API ──────────────────────────────────────────────────────────────────

def _find_cludo_ids() -> tuple[int | None, int | None]:
    """
    Henter ida.dk/soeg og finder customerId + engineId i page source.
    Cludo's JS-snippet ser typisk sådan ud:
        cludoSettings = { customerId: 1234567, engineId: 9876543, ... }
    """
    print("[IDA] Finder Cludo IDs fra ida.dk/soeg...")
    try:
        resp = SESSION.get(IDA_SEARCH_PAGE, timeout=15)
        html = resp.text

        # Prøv alle kendte mønstre
        patterns = [
            r'customerId["\s]*:["\s]*(\d+)',
            r'engineId["\s]*:["\s]*(\d+)',
            r'"customerId"\s*:\s*(\d+)',
            r'"engineId"\s*:\s*(\d+)',
            r'CludoSearch.*?customerId.*?(\d{5,9})',
        ]

        customer_id = None
        engine_id   = None

        for pat in patterns:
            matches = re.findall(pat, html, re.IGNORECASE | re.DOTALL)
            if matches and 'customerId' in pat.lower() and not customer_id:
                customer_id = int(matches[0])
            elif matches and 'engineId' in pat.lower() and not engine_id:
                engine_id = int(matches[0])

        if customer_id and engine_id:
            print(f"[IDA] Fandt IDs: customerId={customer_id}, engineId={engine_id}")
        else:
            print(f"[IDA] Delvist fundet: customerId={customer_id}, engineId={engine_id}")
            print("[IDA] Gem HTML og søg manuelt efter 'customerId' i filen")
            with open("ida_source.html", "w", encoding="utf-8") as f:
                f.write(html)
            print("[IDA] Gemt → ida_source.html")

        return customer_id, engine_id

    except Exception as e:
        print(f"[IDA] Fejl ved ID-søgning: {e}")
        return None, None


def _cludo_search(customer_id: int, engine_id: int, page: int = 1) -> list[dict]:
    """
    POST til Cludo Search API.
    Returnerer liste af raw result-dicts, eller tom liste ved fejl.
    """
    # SiteKey auth: Base64("{customerId}:{engineId}:SearchKey")
    import base64
    site_key = base64.b64encode(
        f"{customer_id}:{engine_id}:SearchKey".encode()
    ).decode()

    url = f"{CLUDO_API_BASE}/{customer_id}/{engine_id}/search"

    body = {**SEARCH_PARAMS, "page": page}

    try:
        resp = SESSION.post(
            url,
            json=body,
            headers={
                "Authorization": f"SiteKey {site_key}",
                "Content-Type": "application/json",
            },
            timeout=15,
        )

        if resp.status_code == 401:
            print("[IDA] 401 Unauthorized — SiteKey virker ikke. Cludo kræver muligvis ApiKey i stedet.")
            print("[IDA] Se ida_cludo_debug.json for response")
            with open("ida_cludo_debug.json", "w") as f:
                f.write(resp.text[:2000])
            return []

        if resp.status_code != 200:
            print(f"[IDA] HTTP {resp.status_code}: {resp.text[:200]}")
            return []

        data = resp.json()

        # Gem første response til inspektion
        if page == 1:
            with open("ida_cludo_response.json", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print("[IDA] Første response gemt → ida_cludo_response.json")
            print(f"[IDA] Response nøgler: {list(data.keys())}")

        # Cludo returnerer typisk: { "TypedDocuments": [...], "TotalDocument": N }
        results = (
            data.get("TypedDocuments") or
            data.get("Documents") or
            data.get("Results") or
            data.get("results") or
            []
        )

        # Cludo pakker ofte results i {"Fields": {...}} per dokument
        unpacked = []
        for r in results:
            if isinstance(r, dict) and "Fields" in r:
                unpacked.append(r["Fields"])
            else:
                unpacked.append(r)

        return unpacked

    except Exception as e:
        print(f"[IDA] API-fejl: {e}")
        return []


# ── Dato-parsing ───────────────────────────────────────────────────────────────

def _parse_date(raw: str) -> tuple[str, str, str]:
    """
    Håndterer:
      ISO:     "2025-04-23T17:00:00"  →  ("2025-04-23", "17:00", "")
      Dansk:   "23. april 2025 kl. 17:00–19:00"
      Dato:    "2025-04-23"
    """
    if not raw:
        return "", "", ""

    # ISO datetime
    m = re.match(r"(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})", raw)
    if m:
        return m.group(1), m.group(2), ""

    # ISO dato
    m = re.match(r"(\d{4}-\d{2}-\d{2})", raw)
    if m:
        return m.group(1), "", ""

    # Dansk format: "23. april 2025 kl. 17:00–19:00"
    raw_l = raw.lower()
    m = re.search(
        r"(\d{1,2})\.\s*(\w+)\s+(\d{4})"
        r"(?:.*?kl\.?\s*(\d{2}:\d{2}))?"
        r"(?:\s*[–\-]\s*(\d{2}:\d{2}))?",
        raw_l
    )
    if m:
        day, month_name, year = int(m.group(1)), m.group(2), int(m.group(3))
        month = DANISH_MONTHS.get(month_name, 0)
        if month:
            return f"{year}-{month:02d}-{day:02d}", m.group(4) or "", m.group(5) or ""

    return "", "", ""


def _guess_category(title: str, cludo_category: str = "") -> str:
    """Kategorisér baseret på Cludo's egen kategori eller titel."""
    cat = cludo_category.lower()
    if "kursus" in cat or "workshop" in cat:
        return "Kursus"
    if "konference" in cat:
        return "Konference"

    t = title.lower()
    if any(w in t for w in ["karriere", "job", "cv", "ansøgning", "løn"]):
        return "Karriere"
    if any(w in t for w in ["netværk", "networking", "mingle"]):
        return "Netværk"
    if any(w in t for w in ["kursus", "workshop", "python", "data", "læring", "intro"]):
        return "Kursus"
    if any(w in t for w in ["konference", "symposium", "seminar"]):
        return "Konference"
    if any(w in t for w in ["studie", "faglig", "ingeniør", "tech talk"]):
        return "Faglig"
    return "Andet"


# ── Standalone test ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import asyncio

    print("=" * 55)
    print("IDA Scraper — Cludo API test")
    print("=" * 55)
    print()
    print("Trin 1: Finder Cludo IDs...")
    customer_id, engine_id = _find_cludo_ids()

    if not customer_id:
        print()
        print("IDs ikke fundet automatisk.")
        print("Åbn ida_source.html i browser og søg efter 'customerId'")
        print("Indsæt derefter manuelt øverst i filen:")
        print("  CUSTOMER_ID = <tallet du finder>")
        print("  ENGINE_ID   = <tallet du finder>")
    else:
        print()
        print(f"Trin 2: Kalder Cludo API (customerId={customer_id}, engineId={engine_id})...")
        results = _cludo_search(customer_id, engine_id, page=1)

        if results:
            print(f"\nFørste resultat - nøgler tilgængelige:")
            print(f"  {list(results[0].keys())}")
            print(f"\nFørste event rådata:")
            print(json.dumps(results[0], ensure_ascii=False, indent=2)[:800])
        else:
            print("Ingen resultater. Tjek ida_cludo_debug.json for fejlbesked.")
            print()
            print("Mulige årsager:")
            print("  - SiteKey auth virker ikke (kræver ApiKey i stedet)")
            print("  - Filter-parametre matcher ikke Cludos felt-navne")
            print("  - Engine ID er forkert")
