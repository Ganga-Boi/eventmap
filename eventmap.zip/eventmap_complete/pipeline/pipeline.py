"""
EventMap — Pipeline (rettet dedup)
====================================
Rettelse fra code review:

PROBLEM: Tidligere dedup brugte title.lower() + date som nøgle.
Det kollapsede fx "Fredagsbar" 25. april og "Fredagsbar" 2. maj
til ét event — fordi titlen er identisk OG date er forskellig,
men "Fredagsbar" samme dag fra to kilder kollapsede til ét.

LØSNING: event_id genereres i schema.py som MD5(source|title|date).
Nøglen inkluderer kilden, så to identiske events fra IDA og manuelt
input på samme dag giver to _forskellige_ event_ids — korrekt adfærd.

Dedup-logik her: hvis event_id kolliderer (genuint duplikat),
behold manuelt input over auto-scraped, ellers behold længst beskrivelse.
"""

import asyncio
import json
from datetime import datetime
from pathlib import Path

from schema import Event
from sheets_adapter import (
    get_sheet, ensure_tabs,
    read_manual_inputs, read_active_sources,
    write_events, update_source_stats, export_json_api,
)
from ida_scraper import IDAScraper
from dtu_library_scraper import DTULibraryScraper

SCRAPERS = [
    IDAScraper(),
    DTULibraryScraper(),
]


def dedup(events: list[Event]) -> list[Event]:
    """
    Korrekt dedup via event_id (MD5 af source|title|date).

    Garanterer:
    - "Fredagsbar 25. april" og "Fredagsbar 2. maj" er to events
    - "IDA kursus 23. april" fra IDA og manuel input er to events
      (forskellig source → forskellig event_id)
    - Ægte duplikat: samme source + titel + dato → behold bedste version
    """
    seen: dict[str, Event] = {}
    for e in events:
        key = e.event_id
        if key not in seen:
            seen[key] = e
            continue

        existing = seen[key]

        # Manuelt input vinder altid over auto-scraped
        if e.is_manual and not existing.is_manual:
            seen[key] = e
            continue

        # Behold den med mest information
        score_new = len(e.description) + len(e.location) + len(e.start_time)
        score_old = len(existing.description) + len(existing.location) + len(existing.start_time)
        if score_new > score_old:
            seen[key] = e

    return list(seen.values())


def sort_events(events: list[Event]) -> list[Event]:
    def key(e: Event):
        try:
            return (0, datetime.fromisoformat(e.date))
        except Exception:
            return (1, datetime.max)  # Events uden dato til sidst
    return sorted(events, key=key)


async def run():
    started = datetime.now()
    print(f"\n{'='*50}")
    print(f"EventMap Pipeline — {started.strftime('%Y-%m-%d %H:%M')}")
    print(f"{'='*50}")

    doc = get_sheet()
    ensure_tabs(doc)
    active_sources = read_active_sources(doc)
    print(f"Aktive kilder: {active_sources}")

    all_events: list[Event] = []
    stats: dict[str, int] = {}
    errors: list[str] = []

    for scraper in SCRAPERS:
        if scraper.source_name not in active_sources:
            continue
        events = await scraper.run()
        all_events.extend(events)
        stats[scraper.source_name] = len(events)

    if "Manuelt" in active_sources:
        manual = read_manual_inputs(doc)
        all_events.extend(manual)
        stats["Manuelt"] = len(manual)

    before = len(all_events)
    all_events = dedup(all_events)
    all_events = sort_events(all_events)
    after = len(all_events)

    write_events(doc, all_events)
    update_source_stats(doc, stats)
    export_json_api(all_events)

    elapsed = (datetime.now() - started).seconds
    print(f"\n{'─'*40}")
    for src, count in stats.items():
        print(f"  {src:<20} {count} events")
    print(f"{'─'*40}")
    print(f"  Duplikater fjernet:  {before - after}")
    print(f"  Finale events:       {after}")
    print(f"  Tid:                 {elapsed}s")
    if errors:
        print(f"  Fejl:                {', '.join(errors)}")
    print(f"{'─'*40}\n")

    # Exit code 1 hvis ingen events overhovedet — fanger Actions
    if after == 0:
        import sys
        print("ADVARSEL: 0 events i output — tjek scrapers og Sheets-forbindelse")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(run())
