"""
EventMap — Kanonisk datamodel
==============================
Dette er single source of truth for hele systemet.
Alle scrapers, manuel input, og UI bruger denne struktur.

Regel: Ingen kilde-specifik logik her.
       Al mapping sker i den respektive scraper/adapter.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Literal


# ── Tilladte værdier ───────────────────────────────────────────────────────────

SOURCE = Literal[
    "IDA",
    "DTU Biblioteket",
    "DTU",
    "Nakkeosten",
    "Fredagsbar",
    "Manuelt",       # Indsendt via input-form
]

CATEGORY = Literal[
    "Faglig",
    "Netværk",
    "Social",
    "Karriere",
    "Kursus",
    "Konference",
    "Andet",
]


# ── Datamodel ──────────────────────────────────────────────────────────────────

@dataclass
class Event:
    """
    Kanonisk event-struktur til EventMap.

    Alle felter er strings — gør det nemt at skrive til/læse fra Google Sheets
    uden type-konverteringslogik i UI-laget.
    """

    # Obligatoriske felter
    title: str                          # "IDA Studieevents: Intro til AI"
    date: str                           # ISO 8601: "2025-04-23"
    source: str                         # Se SOURCE ovenfor
    source_url: str                     # Direkte link til event-siden

    # Tidspunkter
    start_time: str = ""                # "17:00" — tom hvis ukendt
    end_time: str = ""                  # "19:00" — tom hvis ukendt

    # Lokation
    location: str = ""                  # "Online" / "DTU Bygning 101" / "IDA Mødecenter"
    location_url: str = ""              # Google Maps link (valgfrit)

    # Metadata
    organizer: str = ""                 # "IDA Studieevents" / "Nakkeosten" osv.
    category: str = "Andet"            # Se CATEGORY ovenfor
    price: str = ""                     # "Gratis" / "99 kr." / "" (ukendt)
    description: str = ""              # Max 300 tegn
    image_url: str = ""                # Thumbnail (valgfrit)

    # System
    event_id: str = ""                  # Unik ID — genereres automatisk
    scraped_at: str = ""               # ISO timestamp
    is_manual: bool = False            # True hvis indsendt via form

    def __post_init__(self):
        if not self.event_id:
            # Deterministisk ID baseret på kilde + titel + dato
            import hashlib
            raw = f"{self.source}|{self.title.lower().strip()}|{self.date}"
            self.event_id = hashlib.md5(raw.encode()).hexdigest()[:12]

        if not self.scraped_at:
            self.scraped_at = datetime.now().isoformat()

    def to_sheet_row(self) -> list:
        """Returnerer event som liste til Google Sheets (samme rækkefølge som SHEET_HEADERS)."""
        return [
            self.event_id,
            self.title,
            self.date,
            self.start_time,
            self.end_time,
            self.location,
            self.location_url,
            self.organizer,
            self.category,
            self.price,
            self.description,
            self.image_url,
            self.source,
            self.source_url,
            str(self.is_manual),
            self.scraped_at,
        ]

    @classmethod
    def from_sheet_row(cls, row: list) -> "Event":
        """Rekonstruér event fra Google Sheets-række."""
        # Pad med tomme strenge hvis rækken er kortere end forventet
        r = row + [""] * 20
        return cls(
            event_id=r[0],
            title=r[1],
            date=r[2],
            start_time=r[3],
            end_time=r[4],
            location=r[5],
            location_url=r[6],
            organizer=r[7],
            category=r[8],
            price=r[9],
            description=r[10],
            image_url=r[11],
            source=r[12],
            source_url=r[13],
            is_manual=r[14].lower() == "true",
            scraped_at=r[15],
        )

    def to_dict(self) -> dict:
        return asdict(self)


# ── Google Sheets header-rækkefølge ───────────────────────────────────────────
# Skal matche to_sheet_row() præcist

SHEET_HEADERS = [
    "event_id",
    "title",
    "date",
    "start_time",
    "end_time",
    "location",
    "location_url",
    "organizer",
    "category",
    "price",
    "description",
    "image_url",
    "source",
    "source_url",
    "is_manual",
    "scraped_at",
]
