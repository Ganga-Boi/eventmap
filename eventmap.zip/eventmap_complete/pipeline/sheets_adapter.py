"""
EventMap — Google Sheets Adapter
==================================
Al interaktion med Google Sheets samlet her.
Resten af systemet importerer kun denne fil — ikke gspread direkte.

Krav:
    pip install gspread google-auth

Setup:
    1. Google Cloud Console → nyt projekt
    2. Aktivér: Google Sheets API + Google Drive API
    3. IAM → Service Accounts → opret → download JSON som 'credentials.json'
    4. Del dit sheet med service account emailen
    5. Sæt SHEET_ID nedenfor (fra sheet-URL'en)
"""

import json
import os
from typing import Optional
from schema import Event, SHEET_HEADERS

# ── Konfiguration ──────────────────────────────────────────────────────────────

CREDENTIALS_FILE = os.getenv("EVENTMAP_CREDENTIALS", "credentials.json")

# Find dit Sheet ID i URL'en:
# https://docs.google.com/spreadsheets/d/SHEET_ID_HER/edit
SHEET_ID = os.getenv("EVENTMAP_SHEET_ID", "DIN_SHEET_ID_HER")

EVENTS_TAB = "Events"        # Fanen med alle events (auto-genereret + manuelt)
MANUAL_TAB = "Manuel input"  # Fanen brugere udfylder
SOURCES_TAB = "Kilder"       # Oversigt over aktive/inaktive kilder


# ── Forbind ────────────────────────────────────────────────────────────────────

def get_sheet():
    """Returnerer det åbne Google Sheets dokument."""
    try:
        import gspread
        from google.oauth2.service_account import Credentials
    except ImportError:
        raise ImportError("Kør: pip install gspread google-auth")

    scopes = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive",
    ]
    creds = Credentials.from_service_account_file(CREDENTIALS_FILE, scopes=scopes)
    gc = gspread.authorize(creds)
    return gc.open_by_key(SHEET_ID)


def ensure_tabs(doc) -> None:
    """Opret faner og headers hvis de ikke eksisterer."""
    existing = [ws.title for ws in doc.worksheets()]

    # Events-fane
    if EVENTS_TAB not in existing:
        ws = doc.add_worksheet(title=EVENTS_TAB, rows=1000, cols=len(SHEET_HEADERS))
        ws.append_row(SHEET_HEADERS)
        # Frys header-række
        ws.freeze(rows=1)
        print(f"[Sheets] Oprettede fane: {EVENTS_TAB}")

    # Manuel input-fane
    if MANUAL_TAB not in existing:
        ws = doc.add_worksheet(title=MANUAL_TAB, rows=500, cols=10)
        # Kun de felter brugeren skal udfylde — resten auto-udfyldes
        manual_headers = [
            "title", "date", "start_time", "end_time",
            "location", "organizer", "category", "price",
            "description", "source_url",
        ]
        ws.append_row(manual_headers)
        ws.freeze(rows=1)
        print(f"[Sheets] Oprettede fane: {MANUAL_TAB}")

    # Kilder-fane
    if SOURCES_TAB not in existing:
        ws = doc.add_worksheet(title=SOURCES_TAB, rows=50, cols=4)
        ws.append_row(["source", "aktiv", "sidst_scraped", "antal_events"])
        ws.freeze(rows=1)
        # Standard-kilder
        default_sources = [
            ["IDA", "TRUE", "", "0"],
            ["DTU Biblioteket", "TRUE", "", "0"],
            ["DTU", "FALSE", "", "0"],
            ["Nakkeosten", "FALSE", "", "0"],
            ["Manuelt", "TRUE", "", "0"],
        ]
        ws.append_rows(default_sources)
        print(f"[Sheets] Oprettede fane: {SOURCES_TAB}")


# ── Læs ───────────────────────────────────────────────────────────────────────

def read_all_events(doc) -> list[Event]:
    """Henter alle events fra Events-fanen."""
    ws = doc.worksheet(EVENTS_TAB)
    rows = ws.get_all_values()
    if len(rows) <= 1:
        return []
    return [Event.from_sheet_row(row) for row in rows[1:] if row[0]]  # Skip header + tomme


def read_manual_inputs(doc) -> list[Event]:
    """
    Læser manuelt indsendte events fra Manuel input-fanen
    og mapper dem til Event-objekter.
    """
    ws = doc.worksheet(MANUAL_TAB)
    rows = ws.get_all_values()
    if len(rows) <= 1:
        return []

    events = []
    for row in rows[1:]:
        r = row + [""] * 15
        if not r[0]:  # Ingen titel = tom række
            continue
        e = Event(
            title=r[0],
            date=r[1],
            start_time=r[2],
            end_time=r[3],
            location=r[4],
            organizer=r[5],
            category=r[6] or "Andet",
            price=r[7],
            description=r[8][:300],
            source_url=r[9],
            source="Manuelt",
            is_manual=True,
        )
        events.append(e)
    return events


def read_active_sources(doc) -> list[str]:
    """Returnerer liste over aktive kildenavne."""
    try:
        ws = doc.worksheet(SOURCES_TAB)
        rows = ws.get_all_values()
        return [row[0] for row in rows[1:] if len(row) > 1 and row[1].upper() == "TRUE"]
    except Exception:
        return ["IDA", "DTU Biblioteket", "Manuelt"]


# ── Skriv ──────────────────────────────────────────────────────────────────────

def write_events(doc, events: list[Event]) -> None:
    """
    Overskriver Events-fanen med de givne events.
    Bruger batch-skrivning for hastighed.
    """
    ws = doc.worksheet(EVENTS_TAB)
    ws.clear()
    ws.append_row(SHEET_HEADERS)

    if events:
        rows = [e.to_sheet_row() for e in events]
        ws.append_rows(rows, value_input_option="USER_ENTERED")

    print(f"[Sheets] Skrev {len(events)} events til '{EVENTS_TAB}'")


def update_source_stats(doc, stats: dict[str, int]) -> None:
    """Opdatér antal events og sidst-scraped tidspunkt per kilde."""
    from datetime import datetime
    ws = doc.worksheet(SOURCES_TAB)
    rows = ws.get_all_values()

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    for i, row in enumerate(rows[1:], start=2):
        source_name = row[0]
        if source_name in stats:
            ws.update(f"C{i}", now)
            ws.update(f"D{i}", str(stats[source_name]))


# ── API output ─────────────────────────────────────────────────────────────────

def export_json_api(events: list[Event], path: str = "events_api.json") -> None:
    """
    Eksportér events til en JSON-fil der kan serves som et simpelt API.
    UI'en læser fra denne fil — ingen direkte Sheets-adgang i frontend.
    """
    from datetime import datetime

    output = {
        "generated_at": datetime.now().isoformat(),
        "total": len(events),
        "events": [e.to_dict() for e in events],
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"[API] Eksporteret {len(events)} events → {path}")
