"""
EventMap — DTU Bibliotek Scraper
==================================
Henter events via iCal (foretrukket) — DTU bruger Springshare LibCal.
HTML-fallback med Playwright hvis iCal ikke er tilgængeligt.

Krav: pip install icalendar requests
"""

import requests
from datetime import datetime

from base_scraper import BaseScraper
from schema import Event

ICAL_URLS = [
    "https://www.bibliotek.dtu.dk/brug-biblioteket/events/kalender?format=ical",
    "https://www.bibliotek.dtu.dk/brug-biblioteket/events/kalender.ics",
    "https://dtubibliotek.libcal.com/calendar?cid=1&t=g&d=0000-00-00&cal=1&inc=0&format=ical",
]
HTML_URL = "https://www.bibliotek.dtu.dk/brug-biblioteket/events/kalender"


class DTULibraryScraper(BaseScraper):
    source_name = "DTU Biblioteket"

    async def _fetch(self) -> list:
        """Forsøg iCal — fallback til HTML."""
        components = _fetch_ical()
        if components:
            return components
        print(f"[{self.source_name}] iCal ikke tilgængeligt — prøver HTML")
        return await _fetch_html()

    def _parse(self, item) -> Event | None:
        """item er enten iCal-komponent (dict) eller HTML-dict."""
        if item.get("_type") == "ical":
            return _parse_ical(item)
        return _parse_html_item(item)


# ── iCal ──────────────────────────────────────────────────────────────────────

def _fetch_ical() -> list[dict]:
    """Returnerer liste af serialiserede iCal VEVENT komponenter."""
    try:
        from icalendar import Calendar
    except ImportError:
        print("[Bibliotek] Mangler: pip install icalendar")
        return []

    for url in ICAL_URLS:
        try:
            resp = requests.get(url, timeout=8, headers={"User-Agent": "EventMap/1.0"})
            if resp.status_code == 200 and "BEGIN:VCALENDAR" in resp.text:
                cal = Calendar.from_ical(resp.text)
                items = []
                for comp in cal.walk():
                    if comp.name == "VEVENT":
                        items.append(_ical_to_dict(comp))
                print(f"[Bibliotek] iCal OK: {url} ({len(items)} events)")
                return items
        except Exception as e:
            continue
    return []


def _ical_to_dict(comp) -> dict:
    dtstart = comp.get("DTSTART")
    dtend = comp.get("DTEND")
    start = dtstart.dt if dtstart else None
    end = dtend.dt if dtend else None

    return {
        "_type": "ical",
        "title": str(comp.get("SUMMARY", "")).strip(),
        "start": start,
        "end": end,
        "location": str(comp.get("LOCATION", "")).strip(),
        "description": str(comp.get("DESCRIPTION", "")).strip()[:300],
        "url": str(comp.get("URL", "")).strip(),
    }


def _parse_ical(item: dict) -> Event | None:
    if not item.get("title"):
        return None

    start = item["start"]
    end = item["end"]

    if hasattr(start, "hour"):
        date_str = start.strftime("%Y-%m-%d")
        start_time = start.strftime("%H:%M")
        end_time = end.strftime("%H:%M") if end and hasattr(end, "hour") else ""
    elif start:
        date_str = start.strftime("%Y-%m-%d")
        start_time, end_time = "", ""
    else:
        date_str, start_time, end_time = "", "", ""

    return Event(
        title=item["title"],
        date=date_str,
        start_time=start_time,
        end_time=end_time,
        location=item["location"] or "DTU Biblioteket",
        organizer="DTU Biblioteket",
        category="Kursus",
        price="Gratis",
        description=item["description"],
        source="DTU Biblioteket",
        source_url=item["url"] or HTML_URL,
    )


# ── HTML fallback ─────────────────────────────────────────────────────────────

async def _fetch_html() -> list[dict]:
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return []

    items = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        await page.goto(HTML_URL, wait_until="networkidle", timeout=20_000)

        # Springshare LibCal bruger typisk disse klasser
        els = await page.query_selector_all(
            ".s-lc-ea-event, .lc-event, article[class*='event'], .event-item"
        )
        for el in els:
            try:
                t_el = await el.query_selector("h2, h3, .event-title, a")
                title = (await t_el.inner_text()).strip() if t_el else ""
                if not title:
                    continue

                a_el = await el.query_selector("a[href]")
                href = await a_el.get_attribute("href") if a_el else HTML_URL

                d_el = await el.query_selector("time, [class*='date'], [class*='time']")
                raw_date = (await d_el.inner_text()).strip() if d_el else ""

                items.append({"_type": "html", "title": title, "href": href, "raw_date": raw_date})
            except Exception:
                continue

        await browser.close()
    return items


def _parse_html_item(item: dict) -> Event | None:
    if not item.get("title"):
        return None
    href = item.get("href", HTML_URL)
    return Event(
        title=item["title"],
        date=item.get("raw_date", ""),
        location="DTU Biblioteket",
        organizer="DTU Biblioteket",
        category="Kursus",
        price="Gratis",
        source="DTU Biblioteket",
        source_url=href if href.startswith("http") else f"https://www.bibliotek.dtu.dk{href}",
    )


if __name__ == "__main__":
    import asyncio
    scraper = DTULibraryScraper()
    events = asyncio.run(scraper.run())
    for e in events[:5]:
        print(f"  [{e.date}] {e.title}")
