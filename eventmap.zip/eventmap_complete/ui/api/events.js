/**
 * EventMap — /api/events
 * ========================
 * Vercel Serverless Function med in-memory cache.
 *
 * Caching-strategi: stale-while-revalidate
 *   - Første kald henter fra Sheets og cacher i hukommelsen
 *   - Efterfølgende kald inden for TTL returnerer cached data øjeblikkeligt
 *   - Når TTL udløber returneres stale data MENS nyt hentes i baggrunden
 *   - Brugeren venter aldrig på Sheets
 *
 * Vigtigt om Vercel in-memory cache:
 *   Vercel genanvender serverless function-instanser i op til 5–10 min.
 *   Det betyder cachen virker i praksis — men du kan ikke garantere den.
 *   Er det kritisk, brug Vercel KV eller Upstash Redis i stedet (se kommentar).
 *
 * Env vars (sæt i Vercel dashboard):
 *   GOOGLE_SHEET_ID          — Sheet ID fra URL'en
 *   GOOGLE_SERVICE_ACCOUNT   — Service account JSON som string
 *   CACHE_TTL_SECONDS        — Valgfri, default 300 (5 min)
 */

const CACHE_TTL = parseInt(process.env.CACHE_TTL_SECONDS || '300', 10) * 1000;

const SHEET_HEADERS = [
  'event_id','title','date','start_time','end_time','location',
  'location_url','organizer','category','price','description','image_url',
  'source','source_url','is_manual','scraped_at',
];

// ── In-memory cache (lever så længe function-instansen er varm) ────────────
let cache = {
  data: null,        // Sidste vellykkede response
  fetchedAt: 0,      // Timestamp for seneste fetch
  fetching: false,   // Guard mod parallelle fetches
};

// ── Handler ────────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/json');

  const now = Date.now();
  const age = now - cache.fetchedAt;
  const isStale = age > CACHE_TTL;
  const hasCache = cache.data !== null;

  // ── Frisk cache: returner med det samme ──────────────────────────────────
  if (hasCache && !isStale) {
    res.setHeader('Cache-Control', `public, max-age=${Math.floor((CACHE_TTL - age) / 1000)}`);
    res.setHeader('X-Cache', 'HIT');
    return res.status(200).json(cache.data);
  }

  // ── Stale cache: returner gammel data, revalidér i baggrunden ───────────
  if (hasCache && isStale && !cache.fetching) {
    cache.fetching = true;
    // Kick off revalidation — ikke await
    fetchFromSheets().then(data => {
      if (data) { cache.data = data; cache.fetchedAt = Date.now(); }
      cache.fetching = false;
    }).catch(() => { cache.fetching = false; });

    res.setHeader('Cache-Control', 'public, max-age=60, stale-while-revalidate=300');
    res.setHeader('X-Cache', 'STALE');
    return res.status(200).json(cache.data);
  }

  // ── Ingen cache: bloker og hent ──────────────────────────────────────────
  try {
    const data = await fetchFromSheets();
    if (data) {
      cache.data = data;
      cache.fetchedAt = Date.now();
      res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL / 1000}`);
      res.setHeader('X-Cache', 'MISS');
      return res.status(200).json(data);
    }
  } catch (err) {
    console.error('[EventMap] Sheets fetch fejlede:', err.message);
  }

  // ── Total fejl, ingen cache: returner tom response (aldrig 500 til bruger)
  return res.status(200).json({
    generated_at: new Date().toISOString(),
    total: 0,
    events: [],
    _error: 'Data midlertidigt utilgængeligt',
  });
}

// ── Hent fra Google Sheets ──────────────────────────────────────────────────
async function fetchFromSheets() {
  const { GoogleAuth } = await import('google-auth-library');
  const { google } = await import('googleapis');

  const credentials = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT);
  const auth = new GoogleAuth({
    credentials,
    scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
  });

  const sheets = google.sheets({ version: 'v4', auth });
  const resp = await sheets.spreadsheets.values.get({
    spreadsheetId: process.env.GOOGLE_SHEET_ID,
    range: 'Events!A2:P2000',
  });

  const rows = resp.data.values || [];
  const events = rows
    .filter(row => row[0] && row[1]) // event_id + title skal eksistere
    .map(row => Object.fromEntries(
      SHEET_HEADERS.map((h, i) => [h, row[i] ?? ''])
    ));

  return {
    generated_at: new Date().toISOString(),
    total: events.length,
    events,
    _cache_note: 'Hentet direkte fra Google Sheets',
  };
}

// ── Alternativ: Vercel KV (uncomment hvis du vil persistent cache) ──────────
//
// import { kv } from '@vercel/kv';
//
// async function getCachedOrFetch() {
//   const cached = await kv.get('eventmap:events');
//   if (cached) return cached;
//   const fresh = await fetchFromSheets();
//   await kv.set('eventmap:events', fresh, { ex: CACHE_TTL / 1000 });
//   return fresh;
// }
